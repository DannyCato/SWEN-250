# Honda CR-V Hybrid Spec Sheet

## Basic Features
### Range: 
> The _CR-V Hybrid_ has an estimated driving range of up to **330** miles on a single tank of gas and a full charge of the hybrid battery.

> **Wheelbase:** The CR-V Hybrid has a wheelbase of 105.1 inches.
> **Length:** The CR-V Hybrid is 180.6 inches long.q
> **Width:** The CR-V Hybrid is 73.0 inches wide.
> **Height:** The CR-V Hybrid is 66.1 inches tall.