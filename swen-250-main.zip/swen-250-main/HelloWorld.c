#include <stdlib.h>
#include <stdio.h>

int HelloWorld()
{
	printf("Hello! Hi\n");
	return 1;
}

int main() 
{
	HelloWorld();
	return 1;
}
